package org.woodwhales.music.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.woodwhales.music.entity.TagInfo;

/**
 * @author woodwhales on 2024-08-24 22:16
 */
public interface TagInfoMapper extends BaseMapper<TagInfo> {
}
