package org.woodwhales.music.model;

import lombok.Data;

/**
 * @author woodwhales on 2024-05-18 23:32
 */
@Data
public class GenerateVo {

    private String qrCodeUrl;

    private String twoFactorSecret;

}
