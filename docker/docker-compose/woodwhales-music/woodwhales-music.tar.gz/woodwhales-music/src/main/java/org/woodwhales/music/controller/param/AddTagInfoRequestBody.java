package org.woodwhales.music.controller.param;

import lombok.Data;

/**
 * @author woodwhales on 2024-08-25 14:10
 */
@Data
public class AddTagInfoRequestBody {

    private String tagName;

}
