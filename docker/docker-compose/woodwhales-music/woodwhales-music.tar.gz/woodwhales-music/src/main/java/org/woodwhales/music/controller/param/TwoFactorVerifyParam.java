package org.woodwhales.music.controller.param;

import lombok.Data;

/**
 * @author woodwhales on 2024-05-13 23:14
 */
@Data
public class TwoFactorVerifyParam {

    private String code;

}
