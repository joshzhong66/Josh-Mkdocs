package org.woodwhales.music.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.woodwhales.music.entity.SysUser;

/**
 * @author woodwhales on 2024-05-12 20:31
 */
public interface SysUserMapper extends BaseMapper<SysUser> {
}
