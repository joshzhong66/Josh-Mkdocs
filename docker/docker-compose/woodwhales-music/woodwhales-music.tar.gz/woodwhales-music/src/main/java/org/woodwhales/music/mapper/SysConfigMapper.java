package org.woodwhales.music.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.woodwhales.music.entity.SysConfig;

/**
 * @author woodwhales on 2024-05-08 17:35
 */

public interface SysConfigMapper extends BaseMapper<SysConfig> {
}
