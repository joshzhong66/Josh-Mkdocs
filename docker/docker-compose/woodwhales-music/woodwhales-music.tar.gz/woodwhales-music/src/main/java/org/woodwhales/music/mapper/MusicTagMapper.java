package org.woodwhales.music.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.woodwhales.music.entity.MusicTag;

/**
 * @author woodwhales on 2024-08-24 22:43
 */
public interface MusicTagMapper extends BaseMapper<MusicTag> {
}
