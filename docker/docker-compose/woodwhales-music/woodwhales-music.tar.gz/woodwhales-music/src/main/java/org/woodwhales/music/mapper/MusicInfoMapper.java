package org.woodwhales.music.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.woodwhales.music.entity.MusicInfo;

public interface MusicInfoMapper extends BaseMapper<MusicInfo> {
    
}